package com.android_test.zmh.lu_stationerystoreinventorysystem.Tools;

/**
 * Created by student on 10/3/15.
 */
public class UrlManager {

    public static String APIROOTURL ="http://10.10.1.200/LU_Store_MvcV1/api/";
    public static String REQ_DETAIL_URL = "http://10.10.1.200/LU_Store_MvcV1/api/requisition_detailApi/new";


}
