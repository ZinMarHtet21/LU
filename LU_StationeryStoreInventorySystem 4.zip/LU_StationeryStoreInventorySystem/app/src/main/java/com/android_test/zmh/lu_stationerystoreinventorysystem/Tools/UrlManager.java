package com.android_test.zmh.lu_stationerystoreinventorysystem.Tools;

/**
 * Created by student on 10/3/15.
 */
public class UrlManager {

    public static String APIROOTURL ="http://10.10.1.202/LU_Store_MvcV1/api/";

}
