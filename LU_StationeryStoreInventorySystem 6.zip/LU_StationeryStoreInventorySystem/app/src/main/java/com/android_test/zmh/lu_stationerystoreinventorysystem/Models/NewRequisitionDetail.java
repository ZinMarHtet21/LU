package com.android_test.zmh.lu_stationerystoreinventorysystem.Models;

/**
 * Created by student on 15/3/15.
 */
public class NewRequisitionDetail {

    private String item_id;
    private int item_detail_qty;

    public String getItem_id() {
        return item_id;
    }

    public void setItem_id(String item_id) {
        this.item_id = item_id;
    }

    public int getItem_detail_qty() {
        return item_detail_qty;
    }

    public void setItem_detail_qty(int item_detail_qty) {
        this.item_detail_qty = item_detail_qty;
    }
}
